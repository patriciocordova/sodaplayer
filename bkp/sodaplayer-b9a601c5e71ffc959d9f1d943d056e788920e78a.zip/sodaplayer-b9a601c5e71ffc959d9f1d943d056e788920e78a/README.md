#Sodaplayer

***

Sodaplayer is an Android video view based on FFMPEG. You can use this library play RTMP live stream.

## How to use this library

see SodaplayerSample

__contact me : sodapanda20@gmail.com__