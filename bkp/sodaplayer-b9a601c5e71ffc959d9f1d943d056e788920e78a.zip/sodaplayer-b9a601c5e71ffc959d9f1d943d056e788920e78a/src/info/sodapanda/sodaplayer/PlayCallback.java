package info.sodapanda.sodaplayer;

/**
 * Created by qishui on 14-6-18.
 */
public interface PlayCallback {
    public void onConnecting();
    public void onConnected();
    public void onStop();
}
